CREATE DATABASE DW_Hospital
GO
USE DW_Hospital

CREATE TABLE DimPaciente (
    PacienteKey INT PRIMARY KEY IDENTITY,
    CodigoPaciente NVARCHAR(20) UNIQUE NOT NULL,
    Nombre NVARCHAR(50) NOT NULL,
    Apellido NVARCHAR(50) NOT NULL,
    Genero CHAR(1) CHECK (Genero IN ('M','F')),
    FechaNacimiento DATE NOT NULL
);

CREATE TABLE DimDoctor (
    DoctorKey INT PRIMARY KEY IDENTITY,
    CodigoDoctor NVARCHAR(20) UNIQUE NOT NULL,
    Nombre NVARCHAR(50) NOT NULL,
    Especialidad NVARCHAR(50) NOT NULL
);

CREATE TABLE DimHospital (
    HospitalKey INT PRIMARY KEY IDENTITY,
    CodigoHospital NVARCHAR(20) UNIQUE NOT NULL,
    NombreHospital NVARCHAR(100) NOT NULL,
    Ciudad NVARCHAR(50) NOT NULL,
    Departamento NVARCHAR(50) NOT NULL
);

CREATE TABLE DimTiempo (
    TiempoKey INT PRIMARY KEY, 
    Fecha DATE NOT NULL,
    A�o INT NOT NULL,
    Mes INT NOT NULL,
    Dia INT NOT NULL,
    Trimestre INT NOT NULL
);

CREATE TABLE FactMonitoreo (
    MonitoreoKey INT PRIMARY KEY IDENTITY,
    PacienteKey INT NOT NULL,
    DoctorKey INT NOT NULL,
    HospitalKey INT NOT NULL,
    TiempoKey INT NOT NULL,
    
    PresionSistolica INT,
    PresionDiastolica INT,
    Temperatura DECIMAL(4,1), -- �C
    SaturacionOxigeno INT, -- %
    FrecuenciaCardiaca INT,
    
    FOREIGN KEY (PacienteKey) REFERENCES DimPaciente(PacienteKey),
    FOREIGN KEY (DoctorKey) REFERENCES DimDoctor(DoctorKey),
    FOREIGN KEY (HospitalKey) REFERENCES DimHospital(HospitalKey),
    FOREIGN KEY (TiempoKey) REFERENCES DimTiempo(TiempoKey)
);
GO

INSERT INTO DimPaciente (CodigoPaciente, Nombre, Apellido, Genero, FechaNacimiento)
VALUES ('P001', 'Juan', 'P�rez', 'M', '1990-05-20');

INSERT INTO DimDoctor (CodigoDoctor, Nombre, Especialidad)
VALUES ('D001', 'Dra. L�pez', 'Cardiolog�a');

INSERT INTO DimHospital (CodigoHospital, NombreHospital, Ciudad, Departamento)
VALUES ('H001', 'Hospital Central', 'San Salvador', 'San Salvador');

INSERT INTO DimTiempo (TiempoKey, Fecha, A�o, Mes, Dia, Trimestre)
VALUES (20250821, '2025-08-21', 2025, 8, 21, 3);

INSERT INTO FactMonitoreo (PacienteKey, DoctorKey, HospitalKey, TiempoKey,
                           PresionSistolica, PresionDiastolica, Temperatura,
                           SaturacionOxigeno, FrecuenciaCardiaca)
VALUES (1, 1, 1, 20250821, 120, 80, 36.7, 98, 72);
GO