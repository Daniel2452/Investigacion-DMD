create database DW_Super
go
use DW_Super
go

CREATE TABLE DimTiempo (
    TiempoKey INT PRIMARY KEY,   
    Fecha DATE NOT NULL,
    A�o INT NOT NULL,
    Mes NVARCHAR(20) NOT NULL,
	Dia TINYINT NOT NULL,
    Trimestre TINYINT NOT NULL
);

CREATE TABLE DimProveedor (
    ProveedorKey INT IDENTITY(1,1) PRIMARY KEY,
    NombreProveedor NVARCHAR(120) NOT NULL,
    Pais NVARCHAR(80) NOT NULL,
    PlazoEntregaDias INT NULL
);

CREATE TABLE DimProducto (
    ProductoKey INT IDENTITY(1,1) PRIMARY KEY,
    NombreProducto NVARCHAR(100) NOT NULL,
    Categoria NVARCHAR(50) NOT NULL,
    PrecioUnitario DECIMAL(18,2) NOT NULL,
	CostoUnitario DECIMAL(18,2) NOT NULL,
    ProveedorKey INT NOT NULL,
    CONSTRAINT FK_Producto_Proveedor FOREIGN KEY (ProveedorKey) 
        REFERENCES DimProveedor(ProveedorKey)
);

CREATE TABLE DimTienda (
    TiendaKey INT IDENTITY(1,1) PRIMARY KEY,
    NombreTienda NVARCHAR(100) NOT NULL,
    Ciudad NVARCHAR(50) NOT NULL
);

CREATE TABLE FactInventario (
    TiempoKey INT NOT NULL,
    ProductoKey INT NOT NULL,
    TiendaKey INT NOT NULL,
    CantidadInventario INT NOT NULL,
    CostoTotal DECIMAL(18,2) NULL, 
    CONSTRAINT PK_FactInventario PRIMARY KEY (TiempoKey, ProductoKey, TiendaKey),
    CONSTRAINT FK_FactInventario_Tiempo FOREIGN KEY (TiempoKey) REFERENCES DimTiempo(TiempoKey),
    CONSTRAINT FK_FactInventario_Producto FOREIGN KEY (ProductoKey) REFERENCES DimProducto(ProductoKey),
    CONSTRAINT FK_FactInventario_Tienda FOREIGN KEY (TiendaKey) REFERENCES DimTienda(TiendaKey)
);

CREATE TABLE FactVentas (
    TiempoKey INT NOT NULL,
    ProductoKey INT NOT NULL,
    ProveedorKey INT NOT NULL,
    CantidadVendida INT NOT NULL,
    GananciaTotal DECIMAL(18,2) NOT NULL,
    CONSTRAINT PK_FactVentas PRIMARY KEY (TiempoKey, ProductoKey, ProveedorKey),
    CONSTRAINT FK_FactVentas_Tiempo FOREIGN KEY (TiempoKey) REFERENCES DimTiempo(TiempoKey),
    CONSTRAINT FK_FactVentas_Producto FOREIGN KEY (ProductoKey) REFERENCES DimProducto(ProductoKey),
    CONSTRAINT FK_FactVentas_Proveedor FOREIGN KEY (ProveedorKey) REFERENCES DimProveedor(ProveedorKey)
);

GO

CREATE TRIGGER trg_CalcularCostoTotal
ON FactInventario
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE FI
    SET FI.CostoTotal = FI.CantidadInventario * P.CostoUnitario
    FROM FactInventario FI
    INNER JOIN inserted i
        ON FI.TiempoKey = i.TiempoKey
        AND FI.ProductoKey = i.ProductoKey
        AND FI.TiendaKey = i.TiendaKey
    INNER JOIN DimProducto P
        ON FI.ProductoKey = P.ProductoKey;
END;
GO

CREATE TRIGGER trg_InsertaFactVentas
ON FactVentas
INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO FactVentas (TiempoKey, ProductoKey, ProveedorKey, CantidadVendida, GananciaTotal)
    SELECT 
        i.TiempoKey,
        i.ProductoKey,
        i.ProveedorKey,
        i.CantidadVendida,
        i.CantidadVendida * P.PrecioUnitario
    FROM inserted i
    INNER JOIN DimProducto P
        ON i.ProductoKey = P.ProductoKey;
END;
GO

INSERT INTO DimProveedor (NombreProveedor, Pais, PlazoEntregaDias)
VALUES
('Distribuidora La Favorita', 'El Salvador', 3),
('ProAlimentos S.A.', 'El Salvador', 5),
('Importadora Central', 'Guatemala', 7),
('Frutas y Verduras del Valle', 'El Salvador', 2),
('Bebidas Tropicales', 'El Salvador', 4);

INSERT INTO DimProducto (NombreProducto, Categoria, PrecioUnitario, CostoUnitario, ProveedorKey)
VALUES
('Arroz Blanco', 'Cereales', 1.20, 0.80, 1),
('Frijol Negro ', 'Legumbres', 1.50, 1.00, 2),
('Aceite Vegetal', 'Aceites', 2.50, 1.70, 2),
('Pan de Caja Integral', 'Panader�a', 1.80, 1.20, 1),
('Leche Entera', 'L�cteos', 1.10, 0.70, 3),
('Yogurt Natural', 'L�cteos', 1.50, 1.00, 3),
('Manzana Roja', 'Frutas', 2.00, 1.30, 4),
('Cebolla', 'Verduras', 1.20, 0.80, 4),
('Refresco Cola 1.5L', 'Bebidas', 1.80, 1.20, 5),
('Agua Mineral 500ml', 'Bebidas', 0.90, 0.50, 5);

-- ======================
-- TIENDAS
-- ======================
INSERT INTO DimTienda (NombreTienda, Ciudad)
VALUES
('Tienda A', 'San Salvador'),
('Tienda B', 'Santa Tecla'),
('Tienda C', 'Soyapango'),
('Tienda D', 'Santa Ana'),
('Tienda E', 'San Miguel');

INSERT INTO DimTiempo (TiempoKey, Fecha, A�o, Mes, Dia, Trimestre)
VALUES
(20250501, '2024-05-01', 2025, 'Mayo', 1, 2),
(20250502, '2024-05-02', 2025, 'Mayo', 2, 2),
(20250503, '2024-05-03', 2025, 'Mayo', 3, 2),
(20250601, '2024-06-01', 2025, 'Junio', 1, 2),
(20250701, '2024-07-01', 2025, 'Julio', 1, 3),
(20250801, '2024-08-01', 2025, 'Agosto', 1, 3);

INSERT INTO FactInventario (TiempoKey, ProductoKey, TiendaKey, CantidadInventario)
VALUES
(20250501, 1, 1, 100),
(20250501, 2, 1, 80),
(20250501, 3, 1, 50),
(20250501, 4, 2, 60),
(20250501, 5, 2, 120),
(20250501, 6, 3, 70),
(20250501, 7, 3, 90),
(20250501, 8, 4, 100),
(20250501, 9, 5, 200),
(20250501, 10, 5, 150);

INSERT INTO FactVentas (TiempoKey, ProductoKey, ProveedorKey, CantidadVendida)
VALUES
(20250501, 1, 1, 30),
(20250501, 2, 2, 25),
(20250501, 3, 2, 15),
(20250501, 4, 1, 20),
(20250501, 5, 3, 50),
(20250501, 6, 3, 30),
(20250501, 7, 4, 40),
(20250501, 8, 4, 35),
(20250501, 9, 5, 100),
(20250501, 10, 5, 80);

go

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'NT Service\MSOLAP$MSSQLSERVER2')
    CREATE USER [NT Service\MSOLAP$MSSQLSERVER2] FOR LOGIN [NT Service\MSOLAP$MSSQLSERVER2];
GO

-- Asignar rol de solo lectura
ALTER ROLE db_datareader ADD MEMBER [NT Service\MSOLAP$MSSQLSERVER2];
GO
